import boto3
import urllib.parse
import os

s3 = boto3.client('s3')
textract = boto3.client('textract')
ses = boto3.client('ses', region_name='ap-south-1')  # SES is in Mumbai region

# Verified email in Amazon SES (both sender and recipient)
EMAIL_ADDRESS = "rubinrajrubinraj7@gmail.com"

def lambda_handler(event, context):
    print("Received event:", event)

    # Parse bucket and key
    record = event['Records'][0]
    bucket = record['s3']['bucket']['name']
    key = urllib.parse.unquote_plus(record['s3']['object']['key'])

    print(f"Bucket: {bucket}, Key: {key}")

    try:
        # Get the object from S3
        response = s3.get_object(Bucket=bucket, Key=key)
        print("Object fetched on attempt 1")

        # Call Textract to detect document text
        textract_response = textract.detect_document_text(
            Document={
                'S3Object': {
                    'Bucket': bucket,
                    'Name': key
                }
            }
        )

        # Extract text from response
        extracted_text = ""
        for item in textract_response["Blocks"]:
            if item["BlockType"] == "LINE":
                extracted_text += item["Text"] + "\n"

        print("Extracted Text:\n", extracted_text)

        # Send the extracted text via SES
        ses.send_email(
            Source=EMAIL_ADDRESS,
            Destination={'ToAddresses': [EMAIL_ADDRESS]},
            Message={
                'Subject': {'Data': f"Extracted Text from {key}"},
                'Body': {
                    'Text': {'Data': extracted_text or "No text found in the image."}
                }
            }
        )

        print("Email sent successfully.")

        return {
            'statusCode': 200,
            'body': f"Text extracted and emailed from file: {key}"
        }

    except Exception as e:
        print(f"Error: {str(e)}")
        raise e
